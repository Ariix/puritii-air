import React from "react";

export default function rebate() {
  return (
    <div>
      <div className="orange">
        <h3>Save $2500 rmb with this code: iwantcleanair</h3>
      </div>
    </div>
  );
}
