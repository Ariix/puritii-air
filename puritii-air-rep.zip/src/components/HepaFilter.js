import React from "react";

export default function HepaFilter() {
  return (
    <div>
      <h2>Hepa filter</h2>
    </div>
  );
}
