import React from "react";
import couch from "../images/couch.png";

export default function CouchFilter() {
  return (
    <div>
      <img src={couch} alt="couch" />
    </div>
  );
}
