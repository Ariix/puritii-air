import React from "react";

export default function ShadowFade() {
  return <div className="shadowFade"></div>;
}
