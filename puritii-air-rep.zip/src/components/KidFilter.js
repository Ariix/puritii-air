import React from "react";

export default function KidFilter() {
  return (
    <div>
      <h2>Kid Filter</h2>
    </div>
  );
}
