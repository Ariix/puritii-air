import React from "react";

export default function KidFilter() {
  return <div className="kidFilter"></div>;
}
