import React from "react";

export default function Contact() {
  return (
    <div>
      <h2>Contact info for orders</h2>
    </div>
  );
}
