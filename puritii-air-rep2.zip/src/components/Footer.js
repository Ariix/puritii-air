import React from "react";

export default function Footer() {
  return (
    <div>
      <h2> Footer </h2>
    </div>
  );
}
