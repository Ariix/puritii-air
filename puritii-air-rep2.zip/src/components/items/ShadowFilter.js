import React from "react";
import shadow from "../../images/shadow.png";

export default function ShadowFilter() {
  return (
    <div
      className="shadowFilter shadowMove"
      data-rellax-vertical-scroll-axis="xy"
    >
      <img className="topShadow" src={shadow} alt="shadow" />
    </div>
  );
}
